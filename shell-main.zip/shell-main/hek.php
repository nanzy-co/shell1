<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Hacked By Mr.HelloKitty</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    body {
      background-color: #000;
      color: #000;
      font-family: 'Courier New', Courier, monospace;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      min-height: 100vh;
      margin: 0;
      text-align: center;
      padding: 20px;
      box-sizing: border-box;
      font-size: 1em;
    }

    strong {
      font-weight: bold;
    }

    h1 {
      font-size: 1em;
    }

    .marquee-container {
      width: 100%;
      overflow: hidden;
      white-space: nowrap;
    }

    .marquee-content {
      display: inline-block;
      animation: marquee 15s linear infinite;
      padding: 0 100%;
    }

    @keyframes marquee {
      0% { transform: translateX(0%); }
      100% { transform: translateX(-100%); }
    }
    
    .video-link {
        color: cyan;
        text-decoration: none;
        font-size: 1em;
        margin-top: 20px;
        transition: color 0.3s;
    }
    
  </style>
</head>
<body>
  <strong style= "color: red"><h1>Hacked By Mr.HelloKitty</h1></strong>
  <strong style= "color: white">
This Is Not About Hacking, This Is About Humanity, Stop Oppression, Stop The Genocide, Free Palestine</strong>
    <br><br>
    <br><br>
   <strong style= "color: red"> <span>#SAVE G4ZA #OPISRAEL #OPINDIA</span>
  </strong>
  
  <strong style= "color: silver">
    <br>Thanks To:<br>
  </strong>
  
  <div class="marquee-container">
    <div class="marquee-content">
      <strong style= "color:red">- Mr.HelloKitty - Mr.Kyy404 - Yoz4 - InfernalXploit - Finz - Painzy - Team/Aliance: NotraSec - IJJ Comunity - STUDENT TEAM GHOST - CYBER PROTECTOR TEAM - HellR00ters Team - BD Anonymous - Al Mujahedin Force - Indonesian Hacking - </strong>
    </div>
  </div>
</body>
</html>
